function Persona(name, lastName){
    var self  = this;
    self.name: name;
    self.lastName : lastName;
}
